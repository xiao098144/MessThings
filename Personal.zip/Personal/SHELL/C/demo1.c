#include<stdio.h>


struct s
{
	int s;
	char b;
};

int main()
{

	printf("struct int char length is %d\n",sizeof(struct s));

	printf ("Hello World");
	
	return 0;

}