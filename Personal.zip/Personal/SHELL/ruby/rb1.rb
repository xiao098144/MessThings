﻿# encoding:UTF-8

#ruby数据类型
# 单行代码注释

=begin
begin-end  多行代码注释
def fact(n)
if n==1
1
else
n * fact(n-1)
end
end
puts fact(5)

def int a = 5 ;
def int b = 6;
def int c = a + b ;
puts "c = " + c end;
=end

# puts print 都可用作输出  区别puts 带有换行 同比 Java中println与print
# BEGIN {} END{} 代码块  
END {
puts "Ruby END code block"
}

starttime = Time.new;

puts "ruby  rb1 运行开始时间  "+starttime.strftime("%Y-%m-%d %H:%M:%S.%e");

BEGIN{

puts "ruby BEGIN code block "
}
=begin
NumBer 数值类型
1、整型Integer 四字节31位以内 Fixnum 否则为Bignum
可选前异符号 0（octal 八进制） 0x十六进制  0b 二进制 后接数字
下划线在数字字符串中被忽略 仅限位于数字中间
=end
=begin
puts ("整型Integer  ")
Integer i1 = 12;
Integer i2 = -12;
Integer i3 = 023;
Integer i4 = 0x123;
Integer i5 = 0b11;
Integer i6 = 1_6;
puts ("i1 =  #{i1}   i2 =  #{i2}  i3 =   #{i3}   i4 =   #{i4}   i5 =   #{i5}  i6 =  #{i6} ")
=end

=begin
#{param} 将任意类型的param值转换为字符串类型
浮点型Float
=end
=begin
puts ("浮点类型Float")
Float f1 = 123;
Float f2 = 123.1;
Float f3 = 1e2;  # 科学计数法
Float f4 = 4E2;	 # 非必须写法
Float f5 = 4e-2; # 指数前符号  +  -
Float f6 = 64.0;
Float f7 = 4e2;
puts ("f1 = #{f1} - f2 = #{f2} - f3 = #{f3} - f4 = #{f4} - f5 = #{f5} - f6 = #{f6} - f7 = #{f7}")
=end
=begin
算术操作 加减乘除 +-*/ 指数操作  **
=end
=begin
puts("算术操作  加减乘除  指数操作 ** ")
puts ("plus  i1 = #{i1}, f1 = #{f1} i1 + f1 = #{i1 + f1}")
puts ("minus  i2 = #{i2}, f2 = #{f2} i2 - f2 = #{i2 - f2}")
puts ("multiplication  i3 = #{i3}, f3 = #{f3} i3 * f3 = #{i3 * f3}")
puts ("division  i4 = #{i4}, f4 = #{f4} i4 / f4 = #{i4 / f4}")
puts ("index  integer power  i6 = #{i6}, i6 ** 4 = #{i6 ** 4}")
puts ("index fractional power  i6 = #{i6}, f6 = #{f6} i6 / f6 = #{i6/f6} i6 ** (i6/f6) = #{i6 ** (i6 / f6)}")
=end

=begin
字符串类型
Ruby字符串1个8位字节序列  类String的对象
"" 标记的序列可以替换和使用反斜杠符号  ''标记的序列不能替换，且只支持 \\ 和 \'两个反斜杠符号

String name = "字符串类型  "
String rb_str1 = "Ruby Hello world! #{name} "
puts ("双引号字符串 尝试替换  " + rb_str1)
String rb_str2 = 'Ruby Hello world  #{name} '
print ("单引号")
puts (rb_str2)

puts ("反斜杠符号")
puts ('\n 换行符  \r 回车符  \f 换页符  \b 退格符  \a  报警符  \e 转义符  \s 空格符  \nnn  八进制表示法n 0-7  \xnn  n 0-9 a-f A-F  \cx ,\C-x ')
puts ("\\n 换行符 \n==\\r回车符 \r ==\\f 换页符\f ==\\b 退格符\b ==\\a报警符 \a ==\\e转义符 \e\n \\s空格符\s=\s=\s=\s=")
=end

=begin
数组是通过[] 以逗号分隔 支持range(区间)定义
1、数组通过[]索引访问
2、通过赋值操作插入、删除、替换元素
3、通过+、-号进行合并和删除元素，且集合作为新集合出现
4、通过<<号向元数据追加元素
5、通过*号重复数组元素
6、通过 | 和 & 符号做并集 与 交集 操作（注意顺序）

array =["item1",1,2,3,4,"item2","asd",]
print array[0]," ",array[1]," ",array[2]," ",array[3]," ",array[4]," ",array[5]," ",array[6]
puts ""
array2 = [1,22,5,6,8,"item2"]
print array2[0]," ",array2[1]," ",array2[2]," ",array2[3]," ",array2[4]," ",array2[5],"\n"
tmpArray = array | array2
tmpArray2 = array & array2
puts "| 并集结果 "
tmpArray.each do |i|
	print ("#{i} ")
end
puts "\n& 交集结果 "
tmpArray2.each do |i|
	print ("#{i} ")
end
puts "\n赋值操作  替换 "
array[0] = "替换item1";
puts array[0]
=end

=begin 
哈希类型
Ruby哈希类型是通过在{}内放置一系列键值对 通过,逗号分隔 =>  尾部的逗号被忽略

hash = colors = {"red "=>0xf00,"yellow"=>0xff0,"blue"=>0x00f}
hash.each do|key,value|
	print key , "is ", value ,"\n"
end
colors.each do|key,value|
	print key , "is ", value ,"\n"
end
=end

=begin
范围类型
一个区间  设置一个开始值  和 一个结束值 来表示
范围 可使用 s..e 和 s...e 来构造 或者 通过 Range.new 来构造
s..e 代表 包含起点与终点值  s...e 包含起点 不含终点

puts "\n范围类型"
puts "s..e"
(1..5).each do |i|
	print i , ' '
end
puts "\ns...e"
(1...5).each do |i|
	print i ,' '
end
puts ""
=end



endTime = Time.new;
# time.to_i 当前秒数  
puts "运行结束时间  "+endTime.strftime("%Y-%m-%d %H:%M:%S.%e")+" 运行时长  #{endTime.to_i - starttime.to_i}";



