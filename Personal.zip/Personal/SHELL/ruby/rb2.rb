#!/usr/bin/ruby -w
#-*- coding:UTF-8 -*-
# encoding:UTF-8

#ruby类和对象

END {
	puts "Ruby 类和对象 END "
}

starttime = Time.new;

puts "运行开始时间  "+starttime.strftime("%Y-%m-%d %H:%M:%S.%e");

BEGIN{
	puts "Ruby 类和对象 BEGIN"
}

=begin
类以class开始 类名首字母大写  以 end 终结一个类  数据成员介于类定义 和 end之间
四种类型的变量
局部变量：方法中定义的变量，方法外不可用，以 小写字母或者 下划线 "_" 开始 

实例变量：跨任何特定的实例或对象中的方法使用，实例变量可以从对象到对象的改变。实例变量在变量名前以 @ 标识
类变量：类变量可以跨不同对象使用  属于类 是类的一个属性  类变量在变量名之前放置符号 @@
全局变量：类变量不能跨类使用，想要跨类使用的变量，就需要定义全局变量  以美元符号 $ 开始

通过new创建类对象  new 方法属于类方法
可以给 new 方法 传递参数来初始化变量
当想声明 带参数的 new 方法时 需要在创建类时需同时声明方法 initialize 
initialize 是一个特殊类型的方法  将在调用带参数的 new 方法时执行

方法以def 开头 后接 方法名 方法名以小写字母开头 方法以end 结尾 

=end

class RubyClass 
	
	String @realFactor = "realFactsssor"  # 实例变量
	String @@classFactor = "classFactor"  #类变量
	String $globalFactor = "globalFactor"	# 全局变量
	
	Integer @num1 = 1
	Integer @@num2 = 2
	Integer $num3 = 3
		
	def initialize (rf,cf,gf)
		@num1 = 1
		@realFactor = rf
		# @realFactor = rf
		# @@classFactor = cf
		# $globalFactor = gf 
	end
	
	
	def show
		puts "RubyClass realFactor #@realFactor"
		puts "RubyClass classFactor #@@classFactor"
		puts "RubyClass globalFactor #$globalFactor"
		print @realFactor,' ',@@classFactor,' ',$globalFactor,"\n"
	end
	
	def doCompute  # 实例方法
		@num1 +=1  # 此时num1 与默认声明的num1不在同一个作用域 
		@@num2 +=2
		$num3  +=3
		print "RubyClass num1 = #@num1 , num2 = #@@num2 , num3 = #$num3 \n"
	end
	
	def self.classMethod	#类方法
		puts @num1
		puts @realFactor		
	end
end

rbclass = RubyClass.new("newRf","newCf","newGf")
rbclass.show
rbclass.doCompute
RubyClass.classMethod

=begin
Ruby 变量  支持五种类型的变量
一般小写字母、下划线开头：变量 Variable
$开头：全局变量 Global Variable
@开头：实例变量 Instance Variable
@@开头：类变量：Class Variable 类变量被共享在整个的继承链中
大写字母可以：常数Constant

全局变量 未初始化的全局变量默认值为nil ，使用-w选项后 会产生警告
实例变量 未初始化的默认值为nil  使用-w 选项后会产生警告
类变量 @@开头  且必须初始化才能在方法中使用，类变量在定义它的或者模块的子类或子模块可共享使用  
使用-w选项后  重载类变量会产生警告

Ruby局部变量  局部变量的作用域从class 、module、def 、do到相应的结尾 或者 从左大括号到右大括号{}
调用未初始化的局部变量时，它会被解释为调用一个不带参数的方法
对未初始化的局部变量赋值也可以当做是变量声明，变量会一直存在，直到当前域结束，局部变量的生命周期在Ruby解析程序时确定 

常量以大写字母开头，定义类或模块中的常量可以从类或模块内部访问，定义在类或模块外的常量可以被全局访问
变量不能定义在方法内部，不能使用未初始化赋值的常量，不能对已经初始化赋值的常量进行再次赋值  

伪变量
特殊的变量 ，有着局部变量的外观，但行为却像常量，不能给这些变量赋任何值
self : 当前方法的接收器对象
true : 代表true的值
false : 代表false的值
nil : 代表undefined的值
__FILE__ ： 代表当前源文件的名称
__LINE__ :  当前行在源文件的中编号
=end

puts __FILE__  # 打印当前源文件的名称
puts __LINE__  # 打印当前行在源文件中的编号、所在行 

# 常量 示例
Constant1 = 100
Constant2 = 200

class ConstantClass1
	Constant3 = 300
	Constant4 = 400
	def show
		print "Constant1 = #{Constant1} , Constant2 = #{Constant2} , Constant3 = #{Constant3} Constant4 = #{Constant4}  \n"
	end
end

class CC2
	VAR1 = 12
	VAR2 = 23
	def show
		print "Constant1 = #{Constant1} , Constant2 = #{Constant2} , VAR1 = #{VAR1} , VAR2 = #{VAR2}  \n"
	end
end

cc1 = ConstantClass1.new
cc2 = CC2.new
cc1.show
cc2.show 



endTime = Time.new;
# time.to_i 当前秒数  
puts "运行结束时间  "+endTime.strftime("%Y-%m-%d %H:%M:%S.%e")+" 运行时长  #{endTime.to_i - starttime.to_i}";



