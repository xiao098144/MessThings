#!/usr/bin/ruby -w
#-*- coding:UTF-8 -*-
# encoding:UTF-8
# 以下内容中需要注意的内容，可通过搜索 注意(Attention)来查看
#Ruby 运算符

BEGIN{
	puts "Ruby 运算符 BEGIN"	
}
starttime = Time.new;
puts "运行开始时间  "+starttime.strftime("%Y-%m-%d %H:%M:%S.%e");

=begin
对于每个运算符 + - * / % **(指数运算) & | ^  << >> && ||  都有与之对应的缩写赋值运算符  += -= 等等
大多数运算符实际都是方法调用，例如 a + b 被解释为 a.+(b)，其中指向变量a的 +方法被调用 b作为方法的参数

** 指数运算  a**b a的b次方  a = 2 b = 3  a**b = 2的3次方 8 

比较运算符
== ！= >= <=  > < 
<=>  联合比较运算符 如果第一个数等于第二个数 返回0 第一个数大于第二个数返回1 否则返回-1
1 <=> 1 =0  2<=>1 = 1 1<=>2 = -1

=== 用于测试case语句的when子句内的相等  (1...10) === 5 返回true 
.eql? 如果接收器和参数具有相同的类型和相等的值 返回true , 1 == 1.0 为true ，1.eql?(1.0) 为false
equal? 如果接收器和参数具有相同的对象id ,返回true ， 如果aObj 是 bObj的副本，那么 aObj == bObj 返回true ，但a.equal?bObj false，a.equal?aObj 为true

Ruby 并行赋值  多个变量可以通过一行的Ruby代码进行初始化
并行赋值在交换两个变量值时也很有用 a , b = b , a
并行赋值可以同时交换多个变量

=end

a = 10
b = 20
c = 30

d ,e ,f = 40,50,60

puts "原始数据  a = #{a} , b= #{b} , c = #{c} d = #{d} , e = #{e} , f = #{f}"

a,b = e,f
puts "交换以后  a = #{a} , b= #{b} , c = #{c} d = #{d} , e = #{e} , f = #{f}"

# a ,b ,c , d ,e , f = f, e,d, c, b,a
# puts "交换以后  a = #{a} , b= #{b} , c = #{c} d = #{d} , e = #{e} , f = #{f}"

a = 0b101001 
b = 0b010111
=begin 
Ruby  位运算  位运算符作用于位，并逐步执行操作
& 与 都是1 为1 否则为0   a & b = 000001
| 或 有一位为1则为1 否则为0  a | b = 111111
^ 异或 不同为1 相同为0 a ^ b = 111110
~ 非  补码运算符  一元运算符  翻转位效果 补码形式 带符号的二进制数  按位取反  ~a = 010110
移位操作 不足以0补齐
<< 左移  a << 2 = 10100100
>> 右移  a >> 2 = 00001010
to_s()  进制转换  
=end

print 'a & b = ',(a & b).to_s(2) , ' a | b = ',(a|b).to_s(2) , ' a ^ b = ',(a^b).to_s(2),' ~a = ',(~a).to_s(2),' a << 2 = ',(a<<2).to_s(2),' a >> 2 = ',(a>>2).to_s(2),"\n"

=begin 
Ruby 逻辑运算符
and 逻辑与 全真为真
or(||) 逻辑或 任意非零 为真 
&& 逻辑与  全非零为真
not(!)	逻辑非 
=end
a = 10
b = 20
print '逻辑与 a and b = ' , (a and b) ,' 逻辑与a&&b = ',(a&&b),' 逻辑或a or b = ',(a or b ),' 逻辑或a || b = ',(a||b),' 逻辑非 not(a && b) = ',not(a&&b),' 逻辑非!(a&&b) = ',!(a&&b),"\n"


# 三元运算符 ?: 

=begin
Ruby 范围运算符
序列范围用于创建一系列连续的值 ，包含起始点，结束点（看情况而定）和他们之间的值
通过 .. 和 ... 来创建 ，两点 .. 形式 包含起点和终点 ， 三点...仅包含起点，不含终点
=end

puts "defined?运算符"
=begin
defined? 运算符
以方法调用的形式判断传递的表达式（方法或变量）是否已经定义，返回表达式的描述字符串，表达式未定义则返回nil 
局部变量  local_variable
实例变量  instance_variable
类变量    class_variable
全局变量  global_variable	

=end

@car1 
@@car2 = "car2"
$car3 = "car3"
# defined? 变量 方法
print 'defined? vart ',"#{defined? vart}", ' defined? a ',defined? a, ' defined? car1 ',defined? @car1 ,' defined? car2 ',defined? @@car2,' defined? $car3 ',defined? $car3,"\n"
print 'defined? puts ',defined? puts , ' defined? puts(ss) ', defined? puts(ss), "\n"

#defined? super 如果存在可以被super用户调用的方法  可被调用 返回super 否则为nil 
puts "defined? super #{(defined? super)}"

# defined? yield 如果已传递代码块  返回"yield"  否则nil
puts "defined? yiled #{defined? yield}"

=begin
点"."运算符  双冒号运算符 "::"
可以通过在方法名称前加上模块名称和下划线来调用模块方法(to_s()) ，可以通过使用模块名称和两个冒号来引用一个常量
:: 是一元运算符 ，允许在类或模块内部定义常量、实例方法和类方法，可以才类或模块外的任何地方进行访问
注意(Attention)：Ruby中类和方法也可以被当做常量
只需要在表达式的常量名前加上::前缀，即可返回适当的类或模块对象
如果未使用前缀表达式，则默认使用主Object类
=end
	MR_COUNT = "主Object的常量" 							# 定义在主Object类上的常量
module Module1
	MR_COUNT = "init module1的常量" 						# 定义在模块module1的常量
	::MR_COUNT = "GLOBAL_CONSTANT IN MODULE1"     			# 修改全局常量  即 115行
	MR_COUNT = "修改 module1常量值"							# 修改局部常量 
end

print '调用主Object类常量  隐式调用 ', MR_COUNT,' 显式调用Object::MR_COUNT  ',Object::MR_COUNT,"\n"  				
															#此处访问的MR_COUNT 主Object类的全局常量  为116行初始化和119行修改的
# print '',Module1
print '调用Module1全局常量  ', Module1::MR_COUNT,"\n"		#此处访问的是Module1的局部常量，


CONST = ' out there'
class Inside_One
	CONST = proc{' in here'}
	def where_is_my_CONST
		::CONST + ' inside one'
	end
end
class Inside_Two 
	CONST = ' inside two '
	def where_is_my_CONST
		CONST
	end
end

io = Inside_One.new
it = Inside_Two.new

print 'Inside_One.where_is_my_CONST ',io.where_is_my_CONST,"\n"
print 'Inside_Two.where_is_my_CONST ',it.where_is_my_CONST,"\n"
print 'Object::CONST' ,CONST,'  Inside_Two::CONST ',Inside_Two::CONST ,"\n"
print 'Inside_Two::CONST + CONST' ,Inside_Two::CONST + CONST , "\n"
print 'Inside_One::CONST ',Inside_One::CONST,"\n" 
print 'Inside_One::CONST.call = Inside_Two::CONST ',Inside_One::CONST.call + Inside_Two::CONST,"\n"

=begin
:: 常量解析运算符  										 是方法
[][]= 元素引用、元素集合 								 是方法
** 指数运算 											 是方法
!、~、+、- 非、补、一元加(方法名 +@)、一元减(方法名-@)   是方法
*、/、%  乘法、除法、求模								 是方法	
+、- 加法、减法											 是方法
>>、<< 按位右移 、按位左移								 是方法
% 按位与												 是方法	
^、| 按位异或 、按位或									 是方法
<=、<、>、>=  比较运算符								 是方法	
<=>、== 、===、!=、=~、!~								 是方法  (=~、!~不能被定义为方法)
是方法就可以被重载
以下均不是方法
&&  逻辑与
|| 	逻辑或
.. ...  范围 包含、不包含
?:  三元运算符  条件运算符
=、%=、{ /= -=、+=、|=、&=、>>=、<<=、*=、&&=、||=、**= 赋值
defined? 	检查指定符号是否已经定义
not 链接否定
or and 链接组成
=end

END {
	puts "Ruby 运算符 END "
}
endTime = Time.new;
# time.to_i 当前秒数  
puts "运行结束时间  "+endTime.strftime("%Y-%m-%d %H:%M:%S.%e")+" 运行时长  #{endTime.to_i - starttime.to_i}";



