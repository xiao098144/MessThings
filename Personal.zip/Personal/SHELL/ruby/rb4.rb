#!/usr/bin/ruby -w
#-*- coding:UTF-8 -*-
# encoding:UTF-8
#Ruby 条件判断

BEGIN{
	puts "Ruby 条件判断 BEGIN"	
}
starttime = Time.new;
puts "运行开始时间  "+starttime.strftime("%Y-%m-%d %H:%M:%S.%e");

=begin
if conditional [then]
	code...
[elsif conditional [then]

		code...]
[else 
		code...
		]		
end
if 表达式用于条件执行 值 false 或者 nil 为假 ，其余为真 ，注意elsif  不是 else if 、elif
通常省略保留字 then 若想在一行内写出完整的 if 语句  必须以 then 隔开条件式和程式区块
if a == 4 then a=7 print a end 

=end

puts "if elsif else "

x = 1
if x > 2 then  puts "x > 2" end

if x == 2
puts " x == 2"
elsif x > 2
puts "x > 2"
elsif x < 2
puts " x < 2 "
end

=begin
if 修饰符 code if condition  
condition 为真 则执行左边的code
=end

puts "if 修饰符"

puts " x == 1 " if x == 1
puts "x != 2" if x != 1

=begin
unless 语句  
unless conditional [then]
	code
[else 
	code]
end
unless 和 if 作用相反  如果conditional为假 	
=end

puts "unless "

unless x > 2
puts "x < 2"
else puts " x >2"
end

=begin
case 语句
case expression 
[when expression [, expression ...] [then]
	code]...
	[else
		code ]
end	
case 先对一个expression进行匹配判断，然后根据匹配结果进行分支选择
它使用 === 运算符比较 when 指定的expression 一致的话执行when部分的内容
与if修饰符类似  then通常被省略  若想在一行内写出完整的when式  必须以then 隔开 条件式 与 程式区块 
when a == 4 then a = 7 end	
case expre0
	when expre1 , expre2
		stmt1
	when expre3 , expre3
		stmt2
	else stmt3
end
	同比类似 if 判断语句
	if expre1 === expre0 || expre2 === expre0
		stmt1
	elsif expre3 === expre0 || expre4 === expre0
		stmt2
	else stmt3
	end	
=end

$age = 5  
case $age
when 0..4  then puts " 4岁以下 " 
when 5..7  then puts " 5 到 7 岁"
when 8..12 then puts " 8 到 12 岁 "
else puts "13岁以上"  
end
 
# 当 case condition 被省略时 将计算第一个 条件部分为真的when子句的表达式
foo = false
bar = true
fix = false
case
when foo then puts " foo is true" 
when bar then puts " bar is true"
when fix then puts " fix is true"
end 


END {
	puts "Ruby 条件判断 END "
} 
endTime = Time.new;
# time.to_i 当前秒数  
puts "运行结束时间  "+endTime.strftime("%Y-%m-%d %H:%M:%S.%e")+" 运行时长  #{endTime.to_i - starttime.to_i}";



