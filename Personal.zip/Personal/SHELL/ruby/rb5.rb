#!/usr/bin/ruby -w
#-*- coding:UTF-8 -*-
# encoding:UTF-8
# Ruby 循环 while for
BEGIN{
	puts "Ruby循环 BEGIN"
}
startTime = Time.new
puts "开始运行时间  "+startTime.strftime("%y-%m-%d %H:%M:%S.%e")

=begin
while conditional [do|:]
	code
end
conditional 为真 执行code  , do或者:可以忽略 但如果想写成一行 则必须以 do或者:隔开
=end
$a = 1
$num = 5
while $a<$num do
	puts ("while循环中do语句  a = #{$a} ")
	$a += 1
end
# 以下语句执行 报错
# $a=1
# while $a < $num ;
	# puts "while循环中 : 语句 a = #{a}"
	# $a+=1
# end

=begin
while 修饰符 
code while conditional 
conditional 为真时 执行code 

begin 
	code 
end while conditional 
当while 跟在一个没有 rescue 或 ensure 子句的begin语句后面 code会在conditional判断前执行一次
=end
# puts "while 修饰符 code while conditional " ; ($a+=1) puts (" 修饰符  a = #{$a}")  while $a = $num

$a = 1
begin 
	puts "while 修饰符 begin code end while conditional a = #{$a}" 
	$a +=1
end while $a < $num


=begin
Ruby until 语句
until conditional [do]
	code
end
conditional 为假执行code do 可忽略不写 但若想在一行内写出until式 则必须以do隔开
同比 while true until false
=end

until $a >$num 
	puts " until 语句 conditional为假 执行code  a = #{$a}"
	$a+=1
end

=begin
until 修饰符 同比while修饰符  while true  until false
code until conditional 
当conditional未假时执行code 

begin
	code
end until conditional 	
until 修饰符跟在一个没有resuce或者ensure子句的begin语句后面 code会在conditional判断前执行一次

=end

begin
 puts " until 修饰符 begin code end until conditional "
end until $a = $num

=begin
Ruby for语句
for variable [,variable ...] in expression [do]
	code
end
先计算表达式得到一个对象然后针对expression中每一个对象执行一遍code 	
=end

for i in 1..5 do puts "for 循环  单行语句  forvariable in expression do end i = #{i}" end

=begin
for...in循环几乎完全等价于 
(expression).each do |variable [,variable ...]| code end

但是for循环不会为局部变量创建新的作用域
=end

(1..5).each do |i| puts "expression.each do variable code end i = #{i}" end 

=begin
break 语句 
终止最内部的循环  如果在区块内调用则终止相关块的方法 方法返回nil

next 语句  同比Java中for循环 中continue 
调到循环下一个迭代 如果在块内调用  则终止块的执行  yield表达式返回nil
=end


for i in 1..5
	for j in 1..5
		if i == j 
			puts "双重for循环 i==j时 break 当前循环 "
		 break
		 elsif i/j == 2 
			puts " i / j == 2时 next 跳过本次循环 执行下一个 i = #{i} j = #{j}"
			next
			else
		 puts " 双重for循环  i = #{i} j = #{j}"
		end
	end	
end

=begin
redo 重新开始最内部循环的该次迭代  不检查循环条件 如果在块内调用则重新开始yield 或 call
有可能会造成无限循环
=end

for i in 1..3
	for j in 1..3
		if j <= 2
			puts "redo语句 重新开始该次迭代 i = #{i} j =#{j} "
			j+=1
			redo
		else puts 	" redo语句 i = #{i} j =#{j}"
		end
	end	
end

=begin
retry 
注意：从1.9版本以后不支持在循环中使用retry

如果retry 出现在begin表达式的rescue子句中 则从begin主体的开头重新开始
begin 
	do_something
rescue 
	#处理错误
	retry # 重新从begin开始
end	 出现在

retry 出现在迭代内、块内或者for表达式的主体内  则重新开始迭代调用，迭代的参数会重新评估 

for ... 
	retry if conditional  # 重新从i==1 开始
end

=end
ss =15
begin
	puts "retry 语句  ss = #{ss} "+ss.to_s(2)
	if ss%2 != 0
		print 'ss  '+ss
	end	
rescue
	puts "出现异常  执行 rescue "
	ss = 12
	retry	
end
# 以下代码  171: Invalid retry compile error (SyntaxError)
# j = 0;
# for i in 1..5
	# if j>=3
	# retry if i % 3 == 0 
	# puts "retry i = #{i} j = #{j} "
	# j+=1	
	# end
# end





endTime = Time.new
puts "结束运行时间 "+endTime.strftime("%y-%m-%d %H:%M:%S.%e")+" 运行时长  #{endTime.to_i - startTime.to_i}"
END{
	puts "Ruby循环 END"
}