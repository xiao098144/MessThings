#! usr/bin/ruby -w
# -*- coding:UTF-8 -*-
#encoding:UTF-8
#Ruby 方法

=begin
Ruby方法 以小写字母开头 ，不能以大写字母开头 否则可能导致编译错误
def method_name [([arg [= default]]...[, * arg [, &expr ]])]
	expre...
end
def method_name 
	expre..
end	
=end

def method1
	puts "method first na args"
end

#def method2("method2 arg1","method2 arg2")
#	puts "method2 arg1 "+
#end



BEGIN{
print "println test"
	puts "Ruby方法 BEGIN"
}
startTime = Time.new
puts "开始运行时间  "+startTime.strftime("%y-%m-%d %H:%M:%S.%e")




endTime = Time.new
puts "结束运行时间 "+endTime.strftime("%y-%m-%d %H:%M:%S.%e")+" 运行时长  #{endTime.to_i - startTime.to_i}"
END{
	puts "Ruby方法 END"
}